import { Product } from './product/product.model';
export interface AppState {
  readonly product: Product[];
}
