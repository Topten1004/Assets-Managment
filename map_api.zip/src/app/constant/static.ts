export const PRIVATE_URI = 'https://10.10.18.211:5001/';
