export interface Asset {
  tankName: string;
  userEmail: string;
  latitude: string;
  longitude: string;
  amount: string;
}
